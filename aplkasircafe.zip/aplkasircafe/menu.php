<?php
// membuat instance
$daftarMenu=NEW Menu;
// aksi tampil data
if($_GET['aksi']=='tampil'){
// aksi untuk tampil data
$html = null;
$html .='<link rel="stylesheet" href="css/tampil.css">';
$html .='<a href="cetak.php"><button class="buttonDownload">CETAK</button></a>';
$html .='</br>';
$html .='<table border="1" width="80%">
<thead>
<th>No.</th>
<th>Id Menu</th>
<th>Nama Menu</th>
<th>Foto</th>
<th>Harga</th>
<th>Aksi</th>
</thead>
<tbody>';
// variabel $data menyimpan hasil return
$data = $daftarMenu->tampil();
$no=null;
if(isset($data)){
foreach($data as $barisMenu){
$no++;
$html .='<tr>
<td>'.$no.'</td>
<td>'.$barisMenu->id_menu.'</td>
<td>'.$barisMenu->nama_menu.'</td>  
<td>'.$barisMenu->foto.'</td>
<td>'.$barisMenu->harga.'</td>
<td>
<a href="index.php?file=menu&aksi=edit&idmenu='.$barisMenu->id_menu.'"><input type="button" class="btn-update">  </a>
<a href="index.php?file=menu&aksi=hapus&idmenu='.$barisMenu->id_menu.'"> <input type="button" class="btn-delete"></a>
</td>
</tr>';
}
}
$html .='</tbody>
</table>';
echo $html;
}
// aksi tambah data
else if ($_GET['aksi']=='tambah') {
$html =null;
$html .='<link rel="stylesheet" href="css/1.css">';
$html .='<img class="foto" src="css/images/org.png">';
$html .='<div class="container">';
$html .='<form  method="POST" action="index.php?file=menu&aksi=simpan">';
$html .='<h2>Form Tambah Daftar Menu</h2>';
$html .='<div class="container">';
$html .='<div class="input-box">';
$html .='<p>Id Menu</br>';
$html .='<input type="text" name="txtIdmenu" placeholder="Masukan Id Menu" autofocus/></p>';
$html .='</div>';
$html .='<div class="input-box">';
$html .='<p>Nama Menu</br>';
$html .='<input type="text" name="txtNamamenu" placeholder="Masukan Nama Menu" size="30" required/></p>';
$html .='</div>';
$html .='<div class="input-box">';
$html .='<p>Foto</br>';
$html .='<input type="file" name="picture" placeholder=" Masukkan Foto"/></input></p>';
$html .='</div>';
$html .='<div class="input-box">';
$html .='<p>Harga</br>';
$html .='<input type="text" name="txtHarga" placeholder="Masukan Harga Menu" size="30" required/></p>';
$html .='</div>';
$html .='<div class="button-container">';
$html .='<button type="submit" name="tombolSimpan" value="Simpan"/>Simpan</button>';
$html .='</div>';
$html .='</form>';
$html .='</div>';
$html .='</div>';
echo $html;
}
// aksi tambah data
else if ($_GET['aksi']=='simpan') {

$data=array(
'id_menu'=>$_POST['txtIdmenu'],
'nama_menu'=>$_POST['txtNamamenu'],
'foto'=>$_POST['picture'],
'harga'=>$_POST['txtHarga']
);
// simpan siswa dengan menjalankan method simpan
$daftarMenu->simpan($data);
echo '<meta http-equiv="refresh" content="0; url=index.php?file=menu&aksi=tampil">';
}
// aksi tambah data
else if ($_GET['aksi']=='edit') {
// ambil data siswa
$menu=$daftarMenu->detail($_GET['idmenu']);
    $html =null;
    $html .='<link rel="stylesheet" href="css/1.css">';
    $html .='<img class="foto" src="css/images/org.png">';
    $html .='<div class="container">';
    $html .='<form method="POST" action="index.php?file=menu&aksi=update">';
    $html .='<h3>Form Edit Daftar Menu </h3>';
    $html .='<div class="container">';
    $html .='<div class="input-box">';
    $html .='<p>Id Menu<br/>';
    $html .='<input type="text" name="txtIdmenu" value="'.$menu->id_menu.'" placeholder="Masukan Id Menu" readonly/></p>';
    $html .='</div>';
    $html .='<div class="input-box">';
    $html .='<p>Nama Menu<br/>';
    $html .='<input type="text" name="txtNamaMenu" value="'.$menu->nama_menu.'" placeholder="Masukan Nama Menu" size="30" required autofocus/></p>';
    $html .='</div>';
    $html .='<div class="input-box">';
    $html .='<p>Foto</p>';
    $html .='<input type="file" name="picture" value="'.$menu->foto.'" placeholder=" Masukkan Foto"/></input>';
    $html .='</div>';
    $html .='<div class="input-box">';
    $html .='<p>Harga<br/>';
    $html .='<input type="text" name="txtHarga" value="'.$menu->harga.'" placeholder="Masukan Nama Menu" size="30" required autofocus/></p>';
    $html .='</div>';
    $html .='<div class="button-container">';
    $html .='<button type="submit" name="tombolSimpan" value="Simpan"/>Simpan</button>';
    $html .='</div>';
    $html .='</form>';
    $html .='</div>';
    echo $html;
    }
    // aksi tambah data
    else if ($_GET['aksi']=='update') {
    $data=array(
        'nama_menu'=>$_POST['txtNamaMenu'],
        'harga'=>$_POST['txtHarga'],
        'foto'=>$_POST['picture'],
        );
        $daftarMenu->update($_POST['txtIdmenu'],$data);
        echo '<meta http-equiv="refresh" content="0; 
        url=index.php?file=menu&aksi=tampil">';
        }
        // aksi tambah data
        else if ($_GET['aksi']=='hapus') {
        $daftarMenu->hapus($_GET['idmenu']);
        echo '<meta http-equiv="refresh" content="0; url=index.php?file=menu&aksi=tampil">';
        }
        // aksi tidak terdaftar
        else {
        echo '<p>Error 404 : Halaman tidak ditemukan !</p>';
        }
        ?>    