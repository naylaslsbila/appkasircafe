<!DOCTYPE html>
<html lang="en">
<head>
<title>APLIKASI KASIR</title>
<link rel="stylesheet" href="css/home.css">
</head>
<body>
    <header>
        <div class="logo">
          <p>Nays Cafe</p>
        </div>
        <nav>
            <ul>
            <?php
include('class/Database.php');
include('class/Menu.php');  
?>
                <li><a href="index.php">Home</a> </li>
                <li><a href="index.php?file=menu&aksi=tampil" >Daftar Menu</a></li>
                <li><a href="index.php?file=menu&aksi=tambah">Tambah Daftar Menu</a></li>
                
            </ul>
</nav>
</header>
<?php
if(isset($_GET['file'])){
include($_GET['file'].'.php');
} else {  
echo '<h1 align="center"><img src="css/images/cf.png"></h1>';
}
?>
</body>
</html>